=== Adpia Promo Code ===
Contributors: Dau Phu Trang
Tags: Adpia, Promo, Promo Code, Adpia Promo Code, Adpia Promo
Donate link: https://adpia.vn/
Requires at least: 4.0
Tested up to: 4.8
Requires PHP: 5.6
Stable tag: 1.1
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Plugin hỗ trợ xây dựng và hiển thị tự động danh sách mã giảm giá từ một số nhà cung cấp thương mại điện tử như trên hệ thống ADPIA

== Description ==
Plugin hỗ trợ xây dựng và hiển thị tự động danh sách mã giảm giá từ một số nhà cung cấp thương mại điện tử như trên hệ thống ADPIA như Shopee, Lazada, Tiki,...
Các nhà cung cấp bạn muốn hiển thị mã giảm giá phải được liên kết với hệ thống ADPIA từ tài khoản publisher của bạn, có tại https://newpub.adpia.vn/newpub/offer_list
Nếu có bất kỳ thắc mắc hoặc góp ý nào về vấn đề sử dụng plugin của chúng tôi, xin vui lòng liên hệ với AM (Account Manager) của bạn trên hệ thống ADPIA để được giúp đỡ.
Hoặc bạn cũng có thể liên hệ trực tiếp với chúng tôi : 
Hotline : 024 2260 6075
Email : affiliate@adpia.vn
Địa chỉ : Tầng 30 tòa nhà Handico Phạm Hùng, Nam Từ Liêm, Hà Nội


== Installation ==
1. Upload file \"Adpia-promo-coupon.zip\" tại mục cài mới plugin của Wordpress, phần tải plugin lên.
2. kích hoạt plugin Adpia Promo Coupon.
3. Vào mục Adpia Promo trên thanh menu.
4. Nhập thông tin cần thiết vào biểu mẫu của chúng tôi, sau đó lưu thay đổi.
5. Một đoạn shortcode được sinh ra phía bên dưới, tiến hành copy đoạn mã đó.
6. Dán đoạn mã vừa copy vào bài viết hoặc trang của bạn, bất cứ nơi nào bạn muốn hiển thị mã giảm giá.

== Frequently Asked Questions ==
= Vì sao tôi nên sử dụng plugin này? =
Adpia Promo Coupon là một plugin không chỉ cung cấp rất nhiều mã giảm giá từ các sàn TMĐT một cách nhanh chóng và hoàn toàn tự động, mà còn hỗ trợ xây dựng và hiển thị giao diện đẹp mắt và thân thiện với cả các thiết bị di động.

= Tôi có phải trả chi phí nào để sử dụng plugin này hay không? =
Adpia Promo Coupon là một plugin hoàn toàn miễn phí, bạn không phải trả bất kỳ chi phí nào để có thể sử dụng plugin này.

== Screenshots ==
1. The screenshot description corresponds to screenshot-1.(png|jpg|jpeg|gif).
2. The screenshot description corresponds to screenshot-2.(png|jpg|jpeg|gif).
3. The screenshot description corresponds to screenshot-3.(png|jpg|jpeg|gif).

== Changelog ==
= 0.2 =
* A change since the previous version.
* Another change.

= 0.1 =
* Initial release.

== Upgrade Notice ==
= 0.2 =
Upgrade notices describe the reason a user should upgrade

= 0.1 =
This version fixes a security related bug. Upgrade immediately.