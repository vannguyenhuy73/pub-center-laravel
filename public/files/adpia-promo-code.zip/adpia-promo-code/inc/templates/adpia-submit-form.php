<div class="wrap apc-wrap">
	<div class="apc-plugin-header">
		<span>Welcome to Adpia Promo Code plugin for Wordpress</span>
	</div>
	<div>
		<span>Plugin hỗ trợ xây dựng và hiển thị tự động danh sách mã giảm giá từ một số nhà cung cấp thương mại điện tử như trên hệ thống ADPIA</span>
	</div>
	
	<?php if (isset($_GET['settings_updated'])) { ?>
	
	<div id="message" class="updated">
		<p><strong><?php _e('Settings saved.') ?></strong></p>
	</div>
		
	<?php
} ?>

	<div class="apc-plugin-content">
		<div class="apc-plugin-content-box">
			<div class="apc-plugin-content-left">
				<div class="apc-plugin-content-left-box">
					<form method="post" action="" class="apc-form">
						<?php settings_fields('apc-settings-group'); ?>
						<table class="form-table">
							<tr valign="top">
								<td>
									<h4>Affiliate ID</h4>
									<input type="text" name="apc_option_aid" value="<?php echo get_option('apc_option_aid'); ?>" placeholder="Your Affiliate ID" required />
									<p>Affiliate ID thuộc tài khoản Newpub của bạn trên hệ thống Adpia<br>Bạn có thể lấy tại <a href="https://newpub.adpia.vn/" target="_blank">đây</a></p>
								</td>
							</tr>
							<tr valign="top">
								<td>
									<h4 scope="row">Offer</h4>
									<select name="apc_option_offer" required >
										<option value="shopee">Shopee</option>
										<option value="lazada">Lazada</option>
										<option value="tiki">Tiki</option>
										<option value="sendo">Sendo</option>
										<option value="klook">Klook</option>
										<option value="yes24">Yes24</option>
									</select>
									<p>Nhà cung cấp muốn hiển thị mã giảm giá</p>
								</td>
							</tr>
							<tr valign="top">
								<td>
									<h4 scope="row">Limit</h4>
									<input type="number" name="apc_option_limit" value="<?php echo get_option('apc_option_limit'); ?>" placeholder="Limit Promo Code Per Page" required />
									<p>Số lượng mã giảm giá hiển thị trên 1 trang</p>
								</td>
							</tr>
							<tr valign="top">
								<td>
									<h4 scope="row">Background</h4>
									<input type="color" name="apc_option_bg" value="<?php echo get_option('apc_option_bg'); ?>" required />
									<p>Màu nền chủ đạo của mã giảm giá</p>
								</td>
							</tr>
							<input type="hidden" name="settings_updated" value="iotz1tsbk3fqr2k57l3yj757pzm8d28g" />
						</table>
						<p><input type="submit" name="submit" id="submit" class="apc-submit-button" value="Lưu thay đổi"></p>
					</form>
				</div>
			</div>
			<div class="apc-plugin-content-right">
				<div class="apc-plugin-content-right-box">
					<div class="apc-plugin-ads-item">
						<div class="apc-plugin-ads-item-box">
							<div class="apc-plugin-ads-item-left">
								<img src="<?= plugins_url('../images/coupon.png',dirname(__FILE__) ) ?>">
							</div>
							<div class="apc-plugin-ads-item-right">
								<span>Cập nhật tự động và liên tục danh sách của rất nhiều mã giảm giá trên các trang TMĐT Việt Nam</span>
							</div>
						</div>
					</div>
					<div class="apc-plugin-ads-item">
						<div class="apc-plugin-ads-item-box">
							<div class="apc-plugin-ads-item-left">
								<img src="<?= plugins_url('../images/builder.png',dirname(__FILE__) ) ?>">
							</div>
							<div class="apc-plugin-ads-item-right">
								<span>Hỗ trợ xây dựng và hiển thị giao diện mã giảm giá trên website của bạn</span>
							</div>
						</div>
					</div>
					<div class="apc-plugin-ads-item">
						<div class="apc-plugin-ads-item-box">
							<div class="apc-plugin-ads-item-left">
								<img src="<?= plugins_url('../images/mobile.png',dirname(__FILE__) ) ?>">
							</div>
							<div class="apc-plugin-ads-item-right">
								<span>Giao diện hiển thị thân thiện với cả thiết bị di động</span>
							</div>
						</div>
					</div>
					<div class="apc-plugin-ads-item">
						<div class="apc-plugin-ads-item-box">
							<div class="apc-plugin-ads-item-left">
								<img src="<?= plugins_url('../images/offer.png',dirname(__FILE__) ) ?>">
							</div>
							<div class="apc-plugin-ads-item-right">
								<span>Cung cấp mã giảm giá từ nhiều nhà cung cấp như Shopee, Lazada, Tiki,...</span>
							</div>
						</div>
					</div>
					<div class="apc-plugin-ads-item">
						<div class="apc-plugin-ads-item-box">
							<div class="apc-plugin-ads-item-left">
								<img src="<?= plugins_url('../images/free.png',dirname(__FILE__) ) ?>">
							</div>
							<div class="apc-plugin-ads-item-right">
								<span>Plugin hoàn toàn miễn phí</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<?php if(!empty(get_option('apc_option_aid'))) { ?>
	<div class="apc-shortcode-input">
		<input class="regular-text" type="text" name="copy-shortcode-input" value="[adpia_promo_code aff='<?= get_option('apc_option_aid') ?>' offer='<?= get_option('apc_option_offer') ?>' limit='<?= get_option('apc_option_limit') ?>' bg='<?= get_option('apc_option_bg') ?>']" readonly />
		<div class="apc-copy-button">
			<div class="apc-copy-button-icon"></div>
		</div>
	</div>
	<p style="text-align: center;">Sao chép đoạn mã sau vào bài viết của bạn, nơi bạn muốn hiển thị mã giảm giá</p>
	<?php } ?>
</div>
<script>
	var copy_btn = document.querySelectorAll(".apc-copy-button")[0];
	copy_btn.addEventListener("click", function(){
		var input = document.querySelectorAll('.apc-shortcode-input input[name="copy-shortcode-input"]')[0];
		input.select();
		input.setSelectionRange(0, 99999);
		document.execCommand("copy");
		toastr.success('Hãy bắt đầu với việc dán đoạn mã vào bất kỳ nơi nào mà bạn muốn.', 'Sao chép thành công!',);
	});
</script>