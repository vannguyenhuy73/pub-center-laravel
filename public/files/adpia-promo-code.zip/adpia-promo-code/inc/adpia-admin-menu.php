<?php 
	
	wp_register_style( 'input_option_css', plugins_url( '/css/adpia_input_option.css', dirname(__FILE__) ));
	
	wp_register_style( 'toastr_css', plugins_url( '/lib/toastr.min.css', dirname(__FILE__) ));
	
	wp_register_script( 'toastr_js', plugins_url( '/lib/toastr.min.js', dirname(__FILE__) ));
	
	function register_mysettings() {
		register_setting( 'apc-settings-group', 'apc_option_aid' );
		register_setting( 'apc-settings-group', 'apc_option_offer' );
		register_setting( 'apc-settings-group', 'apc_option_limit' );
		register_setting( 'apc-settings-group', 'apc_option_bg' );
	}
	 
	function apc_create_menu() {
		add_menu_page(
			'Adpia Promo Code Settings', //page title
			'Adpia Promo', //menu title
			'administrator', //capability
			__FILE__, //menu slug
			'apc_settings_page', //function
			plugins_url('images/adpia-icon.png', dirname(__FILE__)), //icon url
			55.5 //position
		);
		add_action( 'admin_init', 'register_mysettings' );
		
		wp_enqueue_style('input_option_css');
		
		wp_enqueue_style('toastr_css');
		
		wp_enqueue_script( 'toastr_js' );
	}
	
	add_action('admin_menu', 'apc_create_menu'); 
	 
	function apc_settings_page() {
		if(!empty($_POST['settings_updated'])) {
			$aId = $_POST['apc_option_aid'];
			$offerId = $_POST['apc_option_offer'];
			$limit = $_POST['apc_option_limit'];
			$bg = $_POST['apc_option_bg'];
			
			update_option('apc_option_aid', $aId);
			update_option('apc_option_offer', $offerId);
			update_option('apc_option_limit', $limit);
			update_option('apc_option_bg', $bg);
			
			echo "<script>toastr.success('Đoạn mã giành cho bạn đã sẵn sàng chờ bạn phía bên dưới.', 'Cập nhật thành công!',);</script>";
		}
		
		include( dirname(__FILE__) . '/templates/adpia-submit-form.php');
	} 
?>