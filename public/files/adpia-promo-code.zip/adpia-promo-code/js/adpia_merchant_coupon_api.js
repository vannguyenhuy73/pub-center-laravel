var couponTotalArray = '';
var currentArray = [];
var c_limit = 20;
var f_mid = null;
var f_end_date = null;
var clipboard;

let aff = paramsObj.aff;

const frame = document.querySelectorAll(".adpia-merchant-coupon-api")[0];
const offer = paramsObj.offer;
const offset = 0;
const limit = parseInt(paramsObj.limit);

const plugin_url = paramsObj.plugin_url;

let paginates = "";

document.addEventListener('DOMContentLoaded', function(){
	getAllDiscountCodeAPI();
	document.documentElement.style.setProperty('--green', paramsObj.bg);
	loadJs();
	setDOMCss();
});

function getAllDiscountCodeAPI() {
	var logo_merchant_info = [{
		'mid': 'shopee', 
		'logo': plugin_url + 'logo_shopee.png',
		'api_logo' : 'https://bloggiamgia.vn/wp-content/uploads/2020/03/mggshopee.png'
	},{
		'mid': 'lazada', 
		'logo': plugin_url + 'logo_lazada.png',
		'api_logo' : 'https://bloggiamgia.vn/wp-content/uploads/2020/03/logo-lazada-e1586686292987.png'
	},{
		'mid': 'klook',
		'logo': plugin_url + 'logo_klook.png',
		'api_logo' : 'https://bloggiamgia.vn/wp-content/uploads/2020/04/logo-klook.png'
	},{
		'mid': 'sendo',
		'logo': plugin_url + 'logo_sendo.png',
		'api_logo' : 'https://bloggiamgia.vn/wp-content/uploads/2020/06/logo-sendo.png'
	}, {
		'mid': 'tiki',
		'logo': plugin_url + 'logo_tiki.png',
		'api_logo' : 'https://bloggiamgia.vn/wp-content/uploads/2020/04/logo-tiki-e1589181316629.png'
	}, {
		'mid': 'yes24',
		'logo': plugin_url + 'logo_yes24.png',
		'api_logo' : 'https://bloggiamgia.vn/wp-content/uploads/2020/04/logo-yes24.png'
	}];
	
	if(paramsObj.respon_api) {
		var response = paramsObj.respon_api;
		var parser = new DOMParser();
		var parsedHtml = parser.parseFromString(response, "text/html");
		let pTags = parsedHtml.querySelectorAll(".offers-details");
		var html = '';

		logo_merchant_info.forEach(function(val){
			if(offer == val.mid) {
				var output = MultDiscountCodeOutput(pTags, val.mid, val.api_logo, val.logo);
				couponTotalArray += output;
			}
		});

		couponTotalArray = couponTotalArray.substring(0, couponTotalArray.length - 1);
		couponTotalArray = "[" + couponTotalArray + "]";
		couponTotalArray  = JSON.parse(couponTotalArray);

		couponTotalArray.sort(function (a, b) {
			date1 = a.end_date.split('/');
			date2 = b.end_date.split('/');
			x = date1[2] + date1[1] + date1[0];
			y = date2[2] + date2[1] + date2[0];
			return x < y ? -1 : x > y ? 1 : 0;
		});

		if(parseInt(offset) + parseInt(limit) > couponTotalArray.length) {
			for(var i = offset; i < couponTotalArray.length; i++) {
				currentArray.push(couponTotalArray[i]);
			}
		} else {
			for(var i = offset; i < parseInt(offset) + parseInt(limit); i++) {
				currentArray.push(couponTotalArray[i]);
			}
		}

		let rows = '';
		rows += '<div class="adpia-merchant-coupon-api-area">';
		
		for(var i = 0; i < currentArray.length; i++) {
			rows += drawCouponCodeRowSchema(i);
		}
		rows += '</div>';

		if(typeof(num) != "undefined" && num != "" && num != null) {
			var pageTotal = Math.ceil(num / limit);
		} else {
			var pageTotal = Math.ceil((couponTotalArray.length - parseInt(offset)) / limit);
		}

		if(pageTotal > 1) {
			paginates = `<div class="page-area">
			<div class="page-button page-button-hidden" onclick="prevPage(this)">&laquo;</div>`;

			for (var i = 0; i < pageTotal; i++) {
				paginates += '<div class="page-button' + (i == 0 ? ' page-button-selected' : '') + '" onclick="selectPage(' + (i + 1) + ', this)">' + (i + 1) + '</div>';
			}
			paginates += '<div class="page-button" onclick="nextPage(this)">&raquo;</div></div>';
		}

		rows += paginates;
		frame.innerHTML = rows;
	}
}

function MultDiscountCodeOutput(pTags, mid, logo, logo_show) {
	let mgg_discount = [];

	pTags.forEach(function(item) {
		if(item.getElementsByClassName('mgg-logo')[0].getElementsByTagName('img')[0].getAttribute('src') == logo) {
			let title = item.getElementsByClassName("mgg-discount")[0].textContent.trim();
			let desc = item.getElementsByClassName('polyxgo_title')[0].textContent.trim();
			let discount = item.getElementsByClassName('polyxgo_title')[0].getElementsByClassName('pxg_price')[0] ? item.getElementsByClassName('polyxgo_title')[0].getElementsByClassName('pxg_price')[0].textContent.trim() : '';
			let numChild = item.getElementsByClassName('polyxgo_title')[0].children.length;
			let end_date = '';

			for(var j = 0; j < numChild; j++) {
				if(item.getElementsByClassName('polyxgo_title')[0].children[j].textContent.indexOf('Ngày hết hạn') >= 0) {
					end_date = item.getElementsByClassName('polyxgo_title')[0].children[j].textContent.replace('Ngày hết hạn:', '').trim();
					break;
				}
			}

			let code = '';
			let url = '';

			if(item.getElementsByClassName("promotion-button")[0]) {
				url = item.getElementsByClassName("promotion-button")[0].getAttribute('onclick');
			} else if(item.getElementsByClassName("coupon-code")[0]) {
				code = item.getElementsByClassName('coupon-code')[0].getElementsByClassName('vc-mgg')[0].textContent.trim();
				url = item.getElementsByClassName('coupon-code')[0].getElementsByClassName('vc-mgg')[0].getAttribute('onclick');
			}

			url = clearCouponUrl(url);

			mgg_discount.push({mid: mid, title: title, desc: desc, discount: discount, end_date: end_date, code: code, url: url, logo: logo_show});
		}
	});

	var tmp = JSON.stringify(mgg_discount);
	tmp = tmp.substring(1, tmp.length - 1);
	var result = tmp + ",";

	if(mgg_discount.length == 0) {
		result = "";
	}

	return result;
}

function drawCouponCodeRowSchema(i = 0) {
	let row = ``;
	let c_title = currentArray[i]['title'];
	let c_desc = currentArray[i]['desc']
	.replace(' (...chi tiết)', '')
	.replace('ĐH tối thiểu', '. ĐH tối thiểu')
	.replace('Hiệu lực lúc', '. Hiệu lực lúc')
	.replace(' Ngày hết hạn','. Ngày hết hạn')
	.replace(' Ngành hàng', '. Ngành hàng');
	let c_end_date = currentArray[i]['end_date'];
	if(c_end_date.length == 0) {
		c_end_date = 'Vô thời hạn';
	}
	let Ymd = c_end_date.substr(6, 4) + "/" + c_end_date.substr(3, 2) + "/" + c_end_date.substr(0, 2);
	if(!Date.parse(Ymd)) {
		c_end_date = 'Đang cập nhật';
	}
	let c_discount = currentArray[i]['discount'];
	let c_code = currentArray[i]['code'] ? currentArray[i]['code'] : '';
	let c_url = 'https://click.adpia.vn/click.php?m=' + currentArray[i]['mid'] + '&a=' + aff + '&l=8888&l_cd1=3&l_cd2=0&tu=' + currentArray[i]['url'];
	let c_mid = currentArray[i]['mid'];
	let c_logo = currentArray[i]['logo'];
	row += `<div class="adpia-merchant-coupon-api-box">
		<div class="adpia-merchant-coupon-item">
			<div class="adpia-merchant-coupon-item-box">
				<div class="coupon-item-header">
					<div class="coupon-item-merchant-name">` + c_mid[0].toUpperCase() + c_mid.substring(1) + `</div>
					<div class="coupon-item-merchant-num"><img src="` + c_logo + `"></div>
					<div class="coupon-item-merchant-type">` + (c_code.length > 0 ? 'DISCOUNT' : 'COUPON') + `</div>
				</div>
				<div class="coupon-item-content">
					<div class="coupon-item-merchant-text">
						<div class="coupon-item-merchant-title">
							` + c_title + `
						</div>
						<div class="coupon-item-merchant-time">
							Thời Hạn: ` + c_end_date + `
						</div>
						<div class="coupon-item-merchant-desc">
							<span class="coupon-item-merchant-text-content">` + c_desc.substring(0, 100) + (c_desc.length > 100 ? '...' : '') + `</span> <a href="` + c_url + `" target="_blank">Xem ngay &raquo</a>
						</div>
						<div class="coupon-item-merchant-scissors">
							<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#a1a1a1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
							<circle cx="6" cy="6" r="3"></circle>
							<circle cx="6" cy="18" r="3"></circle>
							<line x1="20" y1="4" x2="8.12" y2="15.88"></line>
							<line x1="14.47" y1="14.48" x2="20" y2="20"></line>
							<line x1="8.12" y1="8.12" x2="12" y2="12"></line>
							</svg>
						</div>
					</div>
					<div class="coupon-item-merchant-button">
						<a href="` + c_url + `" target="_blank" onclick="copyClipboardCode('` + c_code + `', this, event)"><div class="coupon-item-merchant-code">
							 ` + (c_code.length > 0 ? (c_code.length > 10 ? c_code.substr(0, 9) : c_code) : '<span style="color: transparent;">.</span>') + 
							 (c_code.length > 0 ? '<div class="coupon-item-merchant-code-hide-layer">' : '<div class="coupon-item-merchant-coupon-hide-layer">') + `
							</div>
						</div></a>
						<div class="coupon-item-merchant-social-button">
							<div class="coupon-item-merchant-share-title">Chia sẻ cho mọi người</div>
							<div class="coupon-item-merchant-btn-item">
								<!--<a href="#" class="func-btn coupon-fb-frame" target="_blank" rel="noopener noreferrer">
									<svg class="niftybutton-facebook" data-tag="fac" data-name="Facebook" viewBox="0 0 512 512" preserveAspectRatio="xMidYMid meet">
										<path d="M211.9 197.4h-36.7v59.9h36.7V433.1h70.5V256.5h49.2l5.2-59.1h-54.4c0 0 0-22.1 0-33.7 0-13.9 2.8-19.5 16.3-19.5 10.9 0 38.2 0 38.2 0V82.9c0 0-40.2 0-48.8 0 -52.5 0-76.1 23.1-76.1 67.3C211.9 188.8 211.9 197.4 211.9 197.4z"></path>
									</svg>
								</a>-->
								<a href="#" class="func-btn coupon-copy-frame" id="coupon-copy-frame-` + i + `" data-flag="false" onclick="copyClipboard(` + i + `, this, event)" target="_blank" rel="noopener noreferrer">
									<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="16px" height="16px" style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg); display: block;" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24">
										<path d="M19 21H8V7h11m0-2H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2m-3-4H4a2 2 0 0 0-2 2v14h2V3h12V1z" fill="#ffffff"/>
									</svg>
								</a>
								<a href="#" class="func-btn coupon-url-frame" id="coupon-url-frame-` + i + `" data-flag="false" onclick="copyClipboard(` + i + `, this, event)" target="_blank" rel="noopener noreferrer">
									<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" style="display: block;" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>
								</a>
								<input type="text" style="opacity: 0; position: absolute; bottom: 0; left: 0; cursor: default;" value="` + c_url + `" id="copy-coupon-link-field-` + i + `">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>`;
	return row;
}

function copyClipboard(index, obj, e) {
	e.preventDefault();
	var ele = document.querySelector("#copy-coupon-link-field-" + index);
	var url = ele.value;
	let btn = obj;
	var flag = btn.getAttribute('data-flag');
	var mess = "";

	if(flag == "false") {
		if(typeof(clipboard) != "undefined") {
			console.log(clipboard);
			clipboard.destroy();
		}
		var request = new XMLHttpRequest();
		request.open('GET', 'https://tinyurl.com/api-create.php?url=' + url, true);
		request.setRequestHeader('Content-Type', 'text/html; charset=UTF-8');
		request.onload = function() {
			if (this.status >= 200 && this.status < 400) {					
				if(obj.classList.contains('coupon-url-frame')){
					btn.setAttribute("data-clipboard-text", this.response);
					btn.setAttribute('data-flag', true);

					clipboard = new ClipboardJS('#coupon-url-frame-' + index);
					mess= "Copy đường dẫn thành công!";
				} else if(obj.classList.contains('coupon-copy-frame')){
					let html = document.querySelectorAll(".coupon-item-merchant-text-content")[0].textContent;
					html += '. Ưu đãi có tại: ' + this.response + ".";
					btn.setAttribute("data-clipboard-text", html.replaceAll('. ', ".\n"));
					btn.setAttribute('data-flag', true);

					clipboard = new ClipboardJS('#coupon-copy-frame-' + index);
					mess= "Copy nội dung thành công!";
				}

				clipboard.on('success', function(e) {
					alert(mess);
				});

				clipboard.on('error', function(e) {
					alert('Có lỗi xảy ra!');
				});

				btn.click();

			} else {

			}
		};
		
		request.onerror = function() {
			alert('Có lỗi xảy ra!!');
		};

		request.send();
	}
}

function copyClipboardCode(discount_code, obj, e) {
	if(discount_code.length > 0) {
		e.preventDefault();
		if(typeof(clipboard) != "undefined") {
			clipboard.destroy();
		}

		obj.setAttribute("data-clipboard-text", discount_code);

		clipboard = new ClipboardJS('.coupon-item-merchant-button a');

		clipboard.on('success', function(e) {
			alert('Copy mã thành công!');
			window.open(obj.getAttribute("href"), '_blank');
		});

		clipboard.on('error', function(e) {
			alert('Có lỗi xảy ra!');
		});
	}
}

function selectPage(page, obj) {

	currentArray = [];
	let rows = '';

	let list_button = document.querySelectorAll(".page-button");

	if(page == 1) {
		list_button[0].classList.add("page-button-hidden");
	} else {
		list_button[0].classList.remove("page-button-hidden");
	}

	if(page == list_button.length - 2) {
		list_button[list_button.length - 1].classList.add("page-button-hidden");
	} else {
		list_button[list_button.length - 1].classList.remove("page-button-hidden");
	}

	for(var i = 0; i < list_button.length; i++) {
		list_button[i].classList.remove("page-button-selected");
	}

	obj.classList.add('page-button-selected');

	p_offset = parseInt(offset) + (page - 1) * parseInt(limit);
	p_limit = parseInt(limit) + (page - 1) * parseInt(limit);
	
	if(p_limit > couponTotalArray.length) {
		p_limit = couponTotalArray.length - offset;
	}

	for(var i = p_offset; i < (parseInt(p_limit) + parseInt(offset)); i++) {
		currentArray.push(couponTotalArray[i]);
	}

	for(var i = 0; i < currentArray.length; i++) {
		rows += drawCouponCodeRowSchema(i);
	}

	document.querySelectorAll(".adpia-merchant-coupon-api-area")[0].innerHTML = rows;
	
	setDOMCss();
}

function prevPage(obj) {
	if(obj.getAttribute("class").indexOf("page-button-hidden") == -1) {
		let list_button = document.querySelectorAll(".page-button");

		for(var i = 0; i < list_button.length; i++) {
			if(list_button[i].getAttribute("class").indexOf("page-button-selected") != -1) {
				if(i != 1) {
					selectPage(i - 1, list_button[i - 1]);
				} else {
					list_button[0].classList.add("page-button-hidden");
				}
				return false;
			}
		}
	}
}

function nextPage(obj) {
	if(obj.getAttribute("class").indexOf("page-button-hidden") == -1) {
		let list_button = document.querySelectorAll(".page-button");

		for(var i = 0; i < list_button.length; i++) {
			if(list_button[i].getAttribute("class").indexOf("page-button-selected") != -1) {
				if(i != list_button.length - 2) {
					selectPage(i + 1, list_button[i + 1]);
				} else {
					list_button[list_button.length - 1].classList.add("page-button-hidden");
				}
				return false;
			}
		}
	}
}

function loadJs() {
	var script = document.createElement('script');
	script.onload = function() {
		console.log("Script loaded and ready");
	};
	script.src = "https://cdn.jsdelivr.net/npm/clipboard@2.0.6/dist/clipboard.min.js";

	document.getElementsByTagName('head')[0].appendChild(script);
}

function clearCouponUrl(url) {
	if(url.indexOf('?url=') != -1) {
		url = url.split('?url=')[1];
	}

	if(url.indexOf('&aff_sub1') != -1) {
		url = url.split('&aff_sub1')[0];
	}

	if(url.indexOf('&sub_aff_id') != -1) {
		url = url.split('&sub_aff_id')[0];
	}

	if(url.indexOf('&sub_aff_id') != -1) {
		url = url.split('&sub_aff_id')[0];
	}

	if(url.indexOf("setTimeout('window.open(\\'") != -1) {
		url = url.split("setTimeout('window.open(\\'")[1];
	}

	if(url.indexOf('?utm_source=') != -1) {
		url = url.split('?utm_source=')[0];
	}

	if(url.indexOf('&utm_source=') != -1) {
		url = url.split('&utm_source=')[0];
	}

	if(url.indexOf('&utm_medium=') != -1) {
		url = url.split('&utm_medium=')[0];
	}

	if(url.indexOf("window.open('") != -1) {
		url = url.split("window.open('")[1];
	}

	return url;
}

function setDOMCss() {
	let ele = document.querySelectorAll(".adpia-merchant-coupon-api")[0];
	let item = document.querySelectorAll(".adpia-merchant-coupon-item");
	let coupon_item_merchant_desc = document.querySelectorAll(".coupon-item-merchant-desc");
	let coupon_item_merchant_name = document.querySelectorAll(".adpia-merchant-coupon-item-box .coupon-item-header .coupon-item-merchant-name");
	let coupon_item_merchant_type = document.querySelectorAll(".adpia-merchant-coupon-item-box .coupon-item-header .coupon-item-merchant-type");
	let coupon_item_merchant_num = document.querySelectorAll(".adpia-merchant-coupon-item-box .coupon-item-header .coupon-item-merchant-num");
	let coupon_item_merchant_code = document.querySelectorAll(".coupon-item-merchant-code");
	let coupon_item_merchant_code_hide_layer = document.querySelectorAll(".coupon-item-merchant-code-hide-layer");
	let coupon_item_merchant_time = document.querySelectorAll(".coupon-item-merchant-time");
	let coupon_item_merchant_share_title = document.querySelectorAll(".coupon-item-merchant-share-title");
	let coupon_item_merchant_title = document.querySelectorAll(".coupon-item-merchant-title");
	let adpia_merchant_coupon_api_area = document.querySelectorAll(".adpia-merchant-coupon-api-area")[0];
	let adpia_merchant_coupon_api_box = document.querySelectorAll(".adpia-merchant-coupon-api-box");
	let adpia_merchant_coupon_item_box = document.querySelectorAll(".adpia-merchant-coupon-item-box");
	let coupon_item_header = document.querySelectorAll(".adpia-merchant-coupon-item-box .coupon-item-header");
	let coupon_item_content = document.querySelectorAll(".adpia-merchant-coupon-item-box .coupon-item-content");
	let coupon_item_merchant_text = document.querySelectorAll(".coupon-item-merchant-text");
	let coupon_item_merchant_button = document.querySelectorAll(".coupon-item-merchant-button");
	let coupon_item_merchant_scissors = document.querySelectorAll(".coupon-item-merchant-scissors");
	
	if(ele.offsetWidth <= 992) {
		for(var i = 0; i < item.length; i++) {
			coupon_item_merchant_desc[i].style.fontSize = "15px";
			coupon_item_merchant_name[i].style.fontSize = "20px";
			coupon_item_merchant_type[i].style.fontSize = "20px";
			coupon_item_merchant_num[i].style.cssText = "height: 58px; padding: 12px 0;";
			coupon_item_merchant_code[i].style.fontSize = "20px";
			coupon_item_merchant_time[i].style.cssText = "font-size: 15px; margin-bottom: 5px;";
			coupon_item_merchant_share_title[i].style.fontSize = "15px";
			coupon_item_merchant_title[i].style.cssText = "font-size: 18px; padding-bottom: 5px;";
		}
		
		for(var i = 0; i < coupon_item_merchant_code_hide_layer.length; i++) {
			coupon_item_merchant_code_hide_layer[i].style.cssText = "font-size: 15px; width: 80%;";
		}
	}
	
	if(ele.offsetWidth <= 768) {
		adpia_merchant_coupon_api_area.style.cssText = "display: flex; flex-wrap: wrap;";
		for(var i = 0; i < item.length; i++) {
			adpia_merchant_coupon_api_box[i].style.width = "50%";
			adpia_merchant_coupon_item_box[i].style.cssText = "flex-wrap: wrap;";
			coupon_item_header[i].style.flex = "calc(100% - 2px);";
			coupon_item_content[i].style.cssText = "flex: calc(100% - 17px); -webkit-box-shadow: 0px 0px 5px 0px rgb(0 0 0 / 75%); -moz-box-shadow: 0px 0px 5px 0px rgba(0,0,0,0.75); box-shadow: 0px 0px 5px 0px rgb(0 0 0 / 75%); flex-wrap: wrap; padding-left: 0;";
			coupon_item_merchant_text[i].style.cssText = "flex: calc(100% - 2px); padding: 15px; border-bottom: 2px dashed #a1a1a1; position: relative;";
			coupon_item_merchant_button[i].style.cssText = "flex: calc(100% - 2px); padding: 15px;";
			coupon_item_merchant_code[i].style.width = "60%";
			coupon_item_merchant_scissors[i].style.cssText = "bottom: -17px; right: 10%; position: absolute; transform: scaleX(-1);";
		}
	}
	
	if(ele.offsetWidth <= 576) {
		for(var i = 0; i < item.length; i++) {
			adpia_merchant_coupon_api_box[i].style.width = "100%";
		}
	}
}