document.addEventListener('DOMContentLoaded', function(){
	setDOMCss();
	
	window.addEventListener('resize', function(){
		setDOMCss();
	});
	
});