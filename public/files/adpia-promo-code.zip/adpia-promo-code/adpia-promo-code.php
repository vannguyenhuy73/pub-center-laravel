<?php
/**
 * Plugin Name: Adpia Promo Code
 * Plugin URI: https://adpia.vn/
 * Description: Plugin hỗ trợ tự động xây dựng giao diện mã giảm giá của ADPIA
 * Version: 1.0
 * Author: Đậu Phụ Trắng
 * Author URI: https://www.facebook.com/lmquang96/
 * License: GPLv3
 */
wp_register_script( 'merchant_coupon_api_js', plugins_url( '/js/adpia_merchant_coupon_api.js', __FILE__ ));

wp_register_script( 'merchant_coupon_responsive_js', plugins_url( '/js/adpia_merchant_coupon_responsive.js', __FILE__ ));
 
wp_register_style( 'merchant_coupon_api_css', plugins_url( '/css/adpia_merchant_coupon_adpi.css',__FILE__ ));
 
include( dirname(__FILE__) . '/inc/adpia-admin-menu.php');
 
if (!class_exists('Adpia_Promo_Code')) {
    class Adpia_Promo_Code {
        function __construct() {
            if (!function_exists('add_shortcode')) {
                return;
            }
            add_shortcode('adpia_promo_code', array(&$this, 'get_coupon_code_from_api'));
        }
		
        function get_coupon_code_from_api($atts = array(), $content = null) {
            extract(shortcode_atts(
				array(
					'aff' => 'A100014896',
					'offer' => 'lazada',
					'limit' => 10,
					'bg' => 'green'
			), $atts));
            $url = 'https://bloggiamgia.vn/wp-admin/admin-ajax.php?action=polyxgo_offers_load_more_data&pg=1&sid=6&cid=9&orderby=date&order=DESC&size=8&ex=false';
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $discount_codes_origin = curl_exec($ch);
            curl_close($ch);
			
			if($discount_codes_origin || 1 == 1) {
				$paramsObj = array(
					"respon_api" => $discount_codes_origin,
					"aff" => $aff,
					"offer" => $offer,
					"limit" => $limit,
					"bg" => $bg,
					"plugin_url" => plugins_url( '/images/',__FILE__ )
				);
				
				wp_localize_script( 'merchant_coupon_api_js', 'paramsObj', $paramsObj );
				
				wp_enqueue_script( 'merchant_coupon_api_js' );
				
				wp_enqueue_script( 'merchant_coupon_responsive_js' );
				
				wp_enqueue_style('merchant_coupon_api_css');
				
				return '<div class="adpia-merchant-coupon-api">loading...</div>';
			}
			
			return;
        }
    }
}
function apc_load() {
    global $apc;
    $apc = new Adpia_Promo_Code();
}
add_action('after_setup_theme', 'apc_load');
?>