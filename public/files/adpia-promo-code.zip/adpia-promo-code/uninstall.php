<?php
	if (!defined('WP_UNINSTALL_PLUGIN')) {
		die;
	}
	
	delete_option( 'apc_option_aid' );
	delete_option( 'apc_option_offer' );
	delete_option( 'apc_option_limit' );
	delete_option( 'apc_option_bg' );
?>