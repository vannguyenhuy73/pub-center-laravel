<?php
/*
Plugin Name: Adpia Deeplink
Plugin URI: http://github.com/thanhtaivtt
Description: Redirect to link product with affiliate link
Author: Taivt
Version: 0.0.0
Author URI: https://toidicode.com
*/

class adpia_deeplink
{
    public function __construct()
    {
        add_shortcode('ad', [$this, 'shortcodeCallback']);
        add_action('admin_menu', [$this, 'adminMenu']);
        add_action("admin_print_footer_scripts", [$this, 'shortcodeScript']);
        add_action('init', [$this, 'newButtonOnTiny']);
    }

    function adminMenu()
    {
        add_options_page('Adpia option', 'Adpia Option', 'manage_options', 'adpia_deeplink',
            [$this, 'adminPageCallback']);
    }

    function generate($url)
    {
        $option = get_option('adpia_deeplink', ['aid' => '']);

        if ($option['aid'] == '') {
            return $url;
        }

        return 'https://pub.adpia.vn/api/deeplink/?a=' . $option['aid'] . '&url=' . rawurlencode($url);
    }

    function shortcodeCallback($atts, $content = '')
    {
        $a = shortcode_atts(['url' => ''], $atts);

        if ($a['url'] == '') {
            return '<a href="' . $this->generate($content) . '" target="_blank">' . $content . '</a>';
        } else {
            if ($content != '') {
                return '<a href="' . $this->generate($a['url']) . '" target="_blank">' . do_shortcode($content) . '</a>';
            }
        }
    }

    function adminPageCallback()
    {
        if (!empty($_POST['adpia']) && $_POST['adpia'] == 'true') {
            $input = [
                'aid' => sanitize_text_field($_REQUEST['adpia_aid']),
            ];

            update_option('adpia_deeplink', $input);
            echo '<h1>Cập nhật thành công</h1><br>';
        }
        $option = get_option('adpia_deeplink', ['uid' => '']);
        ?>

        <div class="wrap">
            <h2>Cài đặt Adpia Deeplink</h2>
            <br>
            <form action="options-general.php?page=adpia_deeplink" method="POST">
                <input type="hidden" name="adpia" value="true">
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="adpia_aid">Affilate ID*:</label></th>
                        <td><input type="text" name="adpia_aid" id="adpia_aid" class="regular-text" value="<?= $option['aid']; ?>" required></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>Lấy Affiliate ID tại <a href="https://pub.adpia.vn/account" target="_blank">đây</a></td>
                    </tr>
                </table>
                <input name="submit" type="submit" class="button button-primary" value="Update">
            </form>
        </div>
        <?php
    }

    function shortcodeScript()
    {
        if (wp_script_is("quicktags")):
            ?>
            <script type="text/javascript">
                //this function is used to retrieve the selected text from the text editor
                function getSel() {
                    var txtarea = document.getElementById("content");
                    var start = txtarea.selectionStart;
                    var finish = txtarea.selectionEnd;
                    return txtarea.value.substring(start, finish);
                }

                QTags.addButton(
                    "adpia_deeplink",
                    "Adpia Deeplink",
                    callback
                );

                function callback() {
                    var selected_text = getSel();
                    if (selected_text == '') {
                        selected_text = 'Tên sản phẩm';
                    }
                    QTags.insertContent('[ad url="Link_san_pham"]' + selected_text + '[/ad]');
                }
            </script>
        <?php
        endif;
    }

    function newButtonOnTiny()
    {
        add_filter("mce_external_plugins", [$this, 'addButton']);
        add_filter("mce_buttons", [$this, 'registerButton']);
    }

    function addButton($plugin_array)
    {
        //enqueue TinyMCE plugin script with its ID.
        $plugin_array["adpia_deeplink_button"] = plugin_dir_url(__FILE__) . "tinymce-button.js";
        return $plugin_array;
    }

    function registerButton($buttons)
    {
        //register buttons with their id.
        array_push($buttons, "adpia_deeplink_button");
        return $buttons;
    }

    static public function install()
    {
	
    }
}

new adpia_deeplink();

register_activation_hook(__FILE__, ['adpia_deeplink', 'install']);
