(function(){
    tinymce.create('tinymce.plugins.AdpiaDeepLinkPlugin', {
        init: function(ed, url) {
            ed.addButton('adpia_deeplink_button', {
                title: 'Adpia Deeplink',
                text: '[Adpia]',
                // icon:'shortcode',
                cmd: 'adpia_deeplink_command',
                /*image: url + '/img/at.png'*/
            });
            ed.addCommand('adpia_deeplink_command', function() {
                var selectedText = ed.selection.getContent();

                var win = ed.windowManager.open({
                    title: 'Deeplink Properties',
                    body: [
                        {
                            type: 'textbox',
                            name: 'addLink',
                            label: 'Link*',
                            minWidth: 500,
                            value: ''
                        },
                        {
                            type: 'textbox',
                            name: 'addContent',
                            label: 'Nội dung hiển thị',
                            minWidth: 500,
                            value : selectedText
                        }
                    ],
                    buttons: [
                        {
                            text: "Ok",
                            subtype: "primary",
                            onclick: function() {
                                win.submit();
                            }
                        },
                        {
                            text: "Cancel",
                            onclick: function() {
                                win.close();
                            }
                        }
                    ],
                    onsubmit: function(e){
                        var returnText = '';
                        if( e.data.addLink.length > 0 && e.data.addContent.length > 0 ) {
                            returnText = '[ad url="'+ e.data.addLink +'"]' + e.data.addContent + '[/ad]';
                        } else if( e.data.addContent.length > 0 ) {
                            returnText = '[ad]' + e.data.addContent + '[/ad]';
                        }
                        ed.execCommand('mceInsertContent', 0, returnText);
                    }
                });
            });

        },
    });
    tinymce.PluginManager.add( 'adpia_deeplink_button', tinymce.plugins.AdpiaDeepLinkPlugin);
})();